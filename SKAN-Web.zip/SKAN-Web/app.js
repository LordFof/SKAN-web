const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const state={
 cards:[], setId:"base1", status:"all", focus:"pokemon",
 element:"all", rarity:"all", sort:"number", scanner:null, deferredInstall:null,
 owned:JSON.parse(localStorage.getItem("skan_owned")||"{}"),
 favorites:JSON.parse(localStorage.getItem("skan_favorites")||"[]")
};
const sets=[
 {id:"base1",name:"BASE SET",universe:"Pokémon"},
 {id:"brainrot_yumcut",name:"BRAINROT",universe:"Brainrot"},
 {id:"sw_masterwork_2025",name:"STAR WARS",universe:"Star Wars"}
];
function save(){localStorage.setItem("skan_owned",JSON.stringify(state.owned));localStorage.setItem("skan_favorites",JSON.stringify(state.favorites));updateCount()}
function updateCount(){const n=Object.keys(state.owned).length;$("#foundCount").textContent=n;$("#collectionSub").textContent=`${n} nalezených / ${state.cards.length} karet`}
function imgFor(c){let p=c.imageLarge||c.imageSmall||"";if(p.startsWith("file:///android_asset/"))p="./assets/"+p.replace("file:///android_asset/","");return p}
function cardSetCount(id){return state.cards.filter(c=>c.setId===id).length}
function rarityNumber(c){if(c.rarityNumber!=null)return c.rarityNumber;return ({Common:2,Uncommon:4,Rare:6,"Rare Holo":8,Legendary:10,Epic:10}[c.rarity]||4)}
function normalizeCard(o,root){
 let rarity=o.rarity||"Common";if(root.setId?.startsWith("brainrot_")&&rarity.toLowerCase()==="epic")rarity="Legendary";
 return {...o,number:Number.parseInt(o.number)||0,setId:o.setId||root.setId,setName:o.setName||root.setName,generation:o.generation||root.generation||1,rarity,rarityNumber:rarityNumber({...o,rarity}),scannable:o.scannable!==false}
}
async function loadCards(){
 for(const fn of ["base1_cards.json","brainrot_yumcut_cards.json","starwars_masterwork_2025_cards.json"]){
  const root=await fetch("./assets/"+fn).then(r=>r.json());state.cards.push(...root.cards.map(c=>normalizeCard(c,root)));
 }
 state.cards.sort((a,b)=>a.generation-b.generation||a.setName.localeCompare(b.setName)||a.number-b.number);
 updateCount();renderSetTabs();renderCollection()
}
function show(view){$$(".view").forEach(v=>v.classList.add("hidden"));$("#"+view+"View").classList.remove("hidden");window.scrollTo(0,0)}
function renderSetTabs(){
 $("#setTabs").innerHTML=sets.map(s=>`<button class="setTab ${s.id===state.setId?"active":""}" data-set="${s.id}">${s.name} · ${cardSetCount(s.id)}</button>`).join("");
 $$(".setTab").forEach(b=>b.onclick=()=>{state.setId=b.dataset.set;state.status="all";renderSetTabs();renderCollection()})
}
function filteredCards(){
 let a=state.cards.filter(c=>c.setId===state.setId);
 if(state.status==="owned")a=a.filter(c=>state.owned[c.id]);
 if(state.status==="missing")a=a.filter(c=>!state.owned[c.id]);
 if(state.element!=="all")a=a.filter(c=>(c.element||"").toLowerCase().includes(state.element));
 if(state.rarity!=="all")a=a.filter(c=>String(rarityNumber(c))===state.rarity);
 const sort=state.sort;
 a.sort((x,y)=>{
  const ox=!!state.owned[x.id],oy=!!state.owned[y.id];
  if(ox!==oy)return ox?-1:1;
  if(sort==="name")return x.name.localeCompare(y.name);
  if(sort==="rarity")return rarityNumber(y)-rarityNumber(x)||x.number-y.number;
  return x.number-y.number;
 });
 return a
}
function renderCollection(){
 const a=filteredCards();
 $("#collectionGrid").innerHTML=a.map(c=>{
  const owned=!!state.owned[c.id], src=owned?imgFor(c):"";
  return `<button class="cardTile ${owned?"owned":"locked"}" data-id="${c.id}">
    ${src?`<img loading="lazy" src="${src}" alt="">`:`<div class="lock">🔒</div>`}
    <span class="num">#${String(c.number).padStart(3,"0")}</span><span class="rarity">${rarityNumber(c)}</span>
    ${owned?`<span class="tileName">${escapeHtml(c.name)}</span>`:""}
  </button>`
 }).join("");
 $$(".cardTile").forEach(b=>b.onclick=()=>openCard(state.cards.find(c=>c.id===b.dataset.id)))
}
function escapeHtml(s){return String(s||"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function openModal(html){$("#modalBody").innerHTML=html;$("#modal").classList.remove("hidden");$(".modalShade").onclick=closeModal;$(".closeBtn")?.addEventListener("click",closeModal)}
function closeModal(){stopScanner();$("#modal").classList.add("hidden");$("#modalBody").innerHTML=""}
function openCard(c){
 const owned=!!state.owned[c.id], src=owned?imgFor(c):"";
 openModal(`<div class="modalTitle"><h3>${owned?"Karta":"Nenalezená karta"}</h3><button class="closeBtn">×</button></div>
 <div class="detail">${src?`<img src="${src}" alt="">`:`<div class="cardTile locked" style="width:220px;margin:auto;aspect-ratio:2/3"><div class="lock">🔒</div><span class="num">#${String(c.number).padStart(3,"0")}</span></div>`}
 <h2>#${String(c.number).padStart(3,"0")} ${escapeHtml(c.name)}</h2><p>${escapeHtml(c.setName)} · ${escapeHtml(c.category||c.cardType||"Karta")}</p>
 <span class="badge">Rarita ${rarityNumber(c)}</span>${owned?`<div class="resultActions"><button id="favCard">${state.favorites.includes(c.id)?"♥ OBLÍBENÁ":"♡ OBLÍBENÁ"}</button></div>`:""}</div>`);
 $("#favCard")?.addEventListener("click",()=>{state.favorites.includes(c.id)?state.favorites=state.favorites.filter(x=>x!==c.id):state.favorites.push(c.id);save();openCard(c)})
}
async function sha256Bytes(text){const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(text));return new Uint8Array(b)}
async function deterministicCardForEan(ean,selectedStyle){
 const d=await sha256Bytes(ean), byte=i=>d[i]&255;
 let pokemon=state.cards.filter(c=>c.setId.startsWith("base1")&&c.scannable!==false);
 let brainrot=state.cards.filter(c=>c.setId.startsWith("brainrot_")&&c.scannable!==false);
 let sw=state.cards.filter(c=>c.setId.startsWith("sw_")&&c.scannable!==false);
 const bucket=((byte(0)<<8)|byte(1))%100;
 const pokemonPercent=selectedStyle==="pokemon"?60:selectedStyle==="brainrot"?40:50;
 const universe=bucket<pokemonPercent?pokemon:brainrot;
 const universeName=bucket<pokemonPercent?"pokemon":"brainrot";
 const usable=universe.length?universe:(sw.length?sw:state.cards.filter(c=>c.scannable!==false));
 const setIds=[...new Set(usable.map(c=>c.setId))], setId=setIds[byte(2)%setIds.length];
 const setCards=usable.filter(c=>c.setId===setId);
 const rb=((byte(3)<<8)|byte(4))%10000;
 let rarity=universeName==="brainrot"?(rb<6000?"Common":rb<8000?"Uncommon":rb<9200?"Rare":rb<9800?"Epic":"Legendary"):(rb<7500?"Common":rb<9200?"Uncommon":rb<9800?"Rare":"Rare Holo");
 let pool=setCards.filter(c=>c.rarity.toLowerCase()===rarity.toLowerCase());if(!pool.length)pool=setCards;
 let total=0;const weights=[];for(const c of pool){const b=await dummyHashByte(c.id);const w=b<51?8:b<128?3:1;total+=w;weights.push(w)}
 let seed=0n;for(let i=5;i<=31;i++)seed=(seed<<5n)^BigInt(d[i%d.length]&31);
 let target=Number(seed%BigInt(total)),cum=0;for(let i=0;i<pool.length;i++){cum+=weights[i];if(target<cum)return pool[i]}return pool[pool.length-1]
}
const hashCache=new Map();
async function dummyHashByte(id){if(hashCache.has(id))return hashCache.get(id);const d=await sha256Bytes(id);const v=d[0]&255;hashCache.set(id,v);return v}
function openScanner(){
 openModal(`<div class="modalTitle"><h3>SKAN — Skenování</h3><button class="closeBtn">×</button></div>
 <div class="scannerWrap"><div class="scanner"><video id="scannerVideo" playsinline muted></video><div class="scanOverlay"><div class="scanFrame"></div></div><div class="scanStatus" id="scanStatus">Namiř kameru na EAN-13 / EAN-8…</div></div></div>
 <div class="resultActions"><button id="manualBtn" class="secondary">ZADAT EAN RUČNĚ</button></div>`);
 $("#manualBtn").onclick=()=>manualEan();
 startScanner()
}
async function startScanner(){
 if(!window.ZXingBrowser){$("#scanStatus").textContent="Skener se nenačetl. Použij ruční EAN.";return}
 try{
  const reader=new ZXingBrowser.BrowserMultiFormatReader();
  state.scanner=reader;
  const devices=await ZXingBrowser.BrowserCodeReader.listVideoInputDevices();
  const preferred=devices.find(d=>/back|rear|environment|zadn/i.test(d.label))||devices[0];
  if(!preferred)throw new Error("Kamera nebyla nalezena");
  reader.decodeFromVideoDevice(preferred.deviceId,"scannerVideo",(result,err)=>{
   if(result){stopScanner();handleEan(result.getText())}
  });
 }catch(e){$("#scanStatus").textContent="Kamera není dostupná. Zkontroluj oprávnění Safari nebo zadej EAN ručně."}
}
function stopScanner(){try{state.scanner?.reset()}catch(e){}state.scanner=null}
function manualEan(){openModal(`<div class="modalTitle"><h3>Zadat EAN</h3><button class="closeBtn">×</button></div><input id="eanInput" inputmode="numeric" pattern="[0-9]*" maxlength="14" style="width:100%;padding:15px;border-radius:12px;background:#1c1c23;color:#fff;border:1px solid #444" placeholder="EAN-13 / EAN-8"><div class="resultActions"><button id="eanGo">SKENOVAT</button></div>`);$("#eanGo").onclick=()=>{const e=$("#eanInput").value.replace(/\D/g,"");if(e.length<8)return;handleEan(e)}}
async function handleEan(ean){
 const old=state.owned[ean];const c=old?state.cards.find(x=>x.id===old):await deterministicCardForEan(ean,state.focus);
 if(!c){openModal(`<h3>Karta nenalezena</h3><button class="wideBtn closeBtn">OK</button>`);return}
 const duplicate=!!old;
 if(!old){state.owned[ean]=c.id;save()}
 const src=imgFor(c);
 openModal(`<div class="modalTitle"><h3>${duplicate?"Už máš tuto kartu":"Nová karta!"}</h3><button class="closeBtn">×</button></div>
 <div class="resultCard"><div>${src?`<img src="${src}" alt="">`:`<div class="cardTile locked"><div class="lock">🔒</div></div>`}</div>
 <div class="resultInfo"><span class="badge">#${String(c.number).padStart(3,"0")} · ${rarityNumber(c)}</span><h2>${escapeHtml(c.name)}</h2><p>${escapeHtml(c.setName)}</p><p>${duplicate?"Tento EAN už byl v tomto zařízení naskenovaný.":"Karta byla přidána do kolekce."}</p>
 <div class="resultActions"><button id="okResult">OK</button></div></div></div>`);
 $("#okResult").onclick=closeModal
}
function openFilters(){
 openModal(`<div class="modalTitle"><h3>Filtry</h3><button class="closeBtn">×</button></div><div class="filterPanel">
 <label>Stav</label><div class="filterChoices">${["all","owned","missing"].map(x=>`<button data-st="${x}" class="${state.status===x?"active":""}">${{all:"Všechny",owned:"Nalezené",missing:"Nenalezené"}[x]}</button>`).join("")}</div>
 <label>Rarita</label><div class="filterChoices"><button data-ra="all" class="${state.rarity==="all"?"active":""}">Vše</button>${[2,4,6,8,10].map(x=>`<button data-ra="${x}" class="${state.rarity===String(x)?"active":""}">${x}</button>`).join("")}</div>
 <label>Řazení</label><div class="filterChoices">${[["number","Číslo karty"],["name","Název A–Z"],["rarity","Rarita"]].map(([v,n])=>`<button data-so="${v}" class="${state.sort===v?"active":""}">${n}</button>`).join("")}</div>
 <div class="resultActions"><button id="applyFilters">POUŽÍT</button></div></div>`);
 $$("[data-st]").forEach(b=>b.onclick=()=>{state.status=b.dataset.st;$$("[data-st]").forEach(x=>x.classList.remove("active"));b.classList.add("active")});
 $$("[data-ra]").forEach(b=>b.onclick=()=>{state.rarity=b.dataset.ra;$$("[data-ra]").forEach(x=>x.classList.remove("active"));b.classList.add("active")});
 $$("[data-so]").forEach(b=>b.onclick=()=>{state.sort=b.dataset.so;$$("[data-so]").forEach(x=>x.classList.remove("active"));b.classList.add("active")});
 $("#applyFilters").onclick=()=>{closeModal();renderCollection()}
}
function bind(){
 $("#scanBtn").onclick=openScanner;$("#collectionBtn").onclick=()=>{show("collection");renderCollection()};$("#collectionTop").onclick=()=>{show("collection");renderCollection()};
 $("#decksBtn").onclick=()=>show("decks");$("#settingsBtn").onclick=()=>show("settings");$("#homeBtn").onclick=()=>show("home");
 $$("[data-back]").forEach(b=>b.onclick=()=>show("home"));$("#filtersBtn").onclick=openFilters;
 $$(".universe-card").forEach(b=>b.onclick=()=>{$$(".universe-card").forEach(x=>x.classList.remove("active"));b.classList.add("active");state.focus=b.dataset.focus});
 $("#resetBtn").onclick=()=>{if(confirm("Opravdu vymazat celou kolekci tohoto zařízení?")){state.owned={};save();renderCollection()}};
 $("#installBtn").onclick=()=>{if(state.deferredInstall){state.deferredInstall.prompt();state.deferredInstall=null}else alert("Na iPhonu použij Safari → Sdílet → Přidat na plochu.")};
 window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();state.deferredInstall=e})
}
bind();loadCards();
if("serviceWorker"in navigator)navigator.serviceWorker.register("./sw.js").catch(()=>{});
