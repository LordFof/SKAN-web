const CACHE="skan-web-v1";
const CORE=["./","./index.html","./style.css","./app.js","./manifest.webmanifest",
"./assets/base1_cards.json","./assets/brainrot_yumcut_cards.json","./assets/starwars_masterwork_2025_cards.json"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting())));
self.addEventListener("activate",e=>e.waitUntil(self.clients.claim()));
self.addEventListener("fetch",e=>{
 if(e.request.method!=="GET")return;
 e.respondWith(caches.match(e.request).then(c=>c||fetch(e.request).then(r=>{
  if(r.ok&&new URL(e.request.url).origin===location.origin){const copy=r.clone();caches.open(CACHE).then(x=>x.put(e.request,copy))}
  return r;
 }).catch(()=>c)));
});