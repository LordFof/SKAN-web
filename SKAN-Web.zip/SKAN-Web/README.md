# SKAN! Web

Samostatná webová/PWA verze SKAN! pro iPhone, iPad, Android a počítače.

## Publikace
1. Nahraj celý obsah tohoto projektu do kořene samostatného repozitáře `LordFof/SKAN-Web`.
2. V Settings → Pages nastav Source na **GitHub Actions**.
3. Každý push do větve `main` automaticky spustí workflow `.github/workflows/deploy.yml`.
4. Výsledná adresa: https://lordfof.github.io/SKAN-Web/

Na iPhonu otevři web v Safari a zvol Sdílet → Přidat na plochu.
