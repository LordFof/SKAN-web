# SKAN! Web / PWA

Webová verze SKAN! určená pro iPhone, iPad, Android a desktop.

## GitHub Pages

1. Nahraj `SKAN.zip` do repozitáře.
2. Workflow `Deploy SKAN Web` rozbalí `SKAN/web`.
3. GitHub → Settings → Pages → **Source: GitHub Actions**.
4. Po doběhnutí workflow bude aplikace na:
   `https://lordfof.github.io/SKAN/`

## iPhone

Otevři web v Safari → Sdílet → **Přidat na plochu**.

## Data

Kolekce je uložena lokálně v prohlížeči. EAN → karta používá SHA-256 deterministický algoritmus přenesený z Android verze.
